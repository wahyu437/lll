// Toggle class active
const navbarNav = document.querySelector('.navbar-nav');
// ketika hamburger menu di klick
document.querySelector('#hamburger-menu').onclik = () => {
    navbarNav.classList.toggle('active');
};

// klik di luar
const hamburger = document.querySelector('#hamburger-menu');

document.addEventListener('click', function(e) {
    if(!hamburger.contains(e.target) && !navbarNav.contains(e.target)){
        navbarNav.classList.remove('active');
    }
});
